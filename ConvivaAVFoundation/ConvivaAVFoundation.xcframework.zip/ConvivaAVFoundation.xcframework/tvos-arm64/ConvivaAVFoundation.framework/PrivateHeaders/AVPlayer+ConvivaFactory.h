//
//  AVPlayer+ConvivaFactory.h
//  Brightcove-Player-Core-BCOVPUIResources
//
//  Created by Senthilkumar Powthiram on 12/04/18.
//

#import <AVFoundation/AVFoundation.h>

@import ConvivaSDK;

@interface AVPlayer (ConvivaFactory)<CISStreamerProxyFactoryProtocol>

@end
